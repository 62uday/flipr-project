import ContactForm from '../components/ContactForm.jsx'
import Footer from '../components/Footer.jsx'
import Hero from '../components/Hero.jsx'
import Navbar from '../components/Navbar.jsx'
import Newsletter from '../components/Newsletter.jsx'
import Projects from '../components/Projects.jsx'
import Testimonials from '../components/Testimonials.jsx'

export default function LandingPage() {
  return (
    <>
      <Navbar />
      <Hero />
      <Projects />
      <Testimonials />
      <ContactForm />
      <Newsletter />
      <Footer />
    </>
  )
}
