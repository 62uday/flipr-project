import ProjectForm from '../components/admin/ProjectForm.jsx'
import ClientForm from '../components/admin/ClientForm.jsx'
import ContactList from '../components/admin/ContactList.jsx'
import SubscriberList from '../components/admin/SubscriberList.jsx'

export default function AdminDashboard() {
  return (
    <main className="min-h-screen bg-slate-950 px-6 py-12 text-white">
      <div className="mx-auto max-w-5xl space-y-10">
        <section className="space-y-4">
          <header>
            <p className="text-sm font-semibold uppercase tracking-[0.4em] text-cyan-300">Admin</p>
            <h1 className="mt-2 text-3xl font-bold">Add New Project</h1>
          </header>
          <ProjectForm />
        </section>

        <section className="space-y-4">
          <header>
            <h2 className="text-2xl font-semibold">Add New Client</h2>
            <p className="text-sm text-slate-300">Create testimonials that will appear in the Happy Clients section.</p>
          </header>
          <ClientForm />
        </section>

        <ContactList />
        <SubscriberList />
      </div>
    </main>
  )
}
