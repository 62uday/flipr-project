import { useEffect, useState } from 'react'
import axios from 'axios'

export default function ContactList() {
  const [contacts, setContacts] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const response = await axios.get('/api/contacts')
        setContacts(response.data)
      } catch (err) {
        console.error('Failed to fetch contacts', err)
        setError('Unable to load contact submissions.')
      }
    }

    fetchContacts()
  }, [])

  return (
    <section className="space-y-4 rounded-2xl border border-white/10 bg-slate-900/60 p-6 shadow-lg">
      <header>
        <h2 className="text-2xl font-semibold">Contact Form Submissions</h2>
      </header>

      {error ? (
        <p className="text-sm text-red-300">{error}</p>
      ) : contacts.length === 0 ? (
        <p className="text-sm text-slate-300">No submissions yet.</p>
      ) : (
        <ul className="space-y-4">
          {contacts.map((contact) => (
            <li key={contact._id} className="rounded-xl border border-white/10 bg-slate-900/80 p-4 text-sm text-slate-100">
              <p className="text-base font-semibold text-white">{contact.fullName}</p>
              <p>Email: {contact.email}</p>
              <p>Mobile: {contact.mobileNumber}</p>
              <p>City: {contact.city}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
