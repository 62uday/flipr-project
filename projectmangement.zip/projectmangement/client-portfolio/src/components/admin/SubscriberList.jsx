import { useEffect, useState } from 'react'
import axios from 'axios'

export default function SubscriberList() {
  const [subscribers, setSubscribers] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchSubscribers = async () => {
      try {
        const response = await axios.get('/api/newsletter')
        setSubscribers(response.data)
      } catch (err) {
        console.error('Failed to fetch subscribers', err)
        setError('Unable to load newsletter subscribers.')
      }
    }

    fetchSubscribers()
  }, [])

  return (
    <section className="space-y-4 rounded-2xl border border-white/10 bg-slate-900/60 p-6 shadow-lg">
      <header>
        <h2 className="text-2xl font-semibold">Newsletter Subscribers</h2>
      </header>

      {error ? (
        <p className="text-sm text-red-300">{error}</p>
      ) : subscribers.length === 0 ? (
        <p className="text-sm text-slate-300">No subscribers yet.</p>
      ) : (
        <ul className="space-y-2 text-sm text-slate-50">
          {subscribers.map((subscriber) => (
            <li key={subscriber._id} className="rounded-lg border border-white/10 bg-slate-900/80 px-4 py-2">
              {subscriber.email}
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
