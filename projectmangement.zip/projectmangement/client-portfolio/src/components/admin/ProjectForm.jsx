import { useState } from 'react'
import axios from 'axios'

export default function ProjectForm() {
  const [formData, setFormData] = useState({ name: '', description: '', image: '' })

  const handleChange = (event) => {
    const { name, value } = event.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (event) => {
    event.preventDefault()

    try {
      await axios.post('/api/projects', formData)
      alert('Project added successfully!')
      setFormData({ name: '', description: '', image: '' })
    } catch (error) {
      console.error('Failed to add project', error)
      alert('Failed to add project.')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 rounded-2xl border border-white/10 bg-slate-900/60 p-6 shadow-lg">
      <div className="flex flex-col gap-2">
        <label className="text-sm font-semibold text-slate-200" htmlFor="name">
          Project Name
        </label>
        <input
          id="name"
          name="name"
          type="text"
          value={formData.name}
          onChange={handleChange}
          placeholder="Enter project title"
          className="rounded-xl border border-white/10 bg-white/90 px-4 py-3 text-slate-900 focus:border-cyan-400 focus:outline-none"
          required
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm font-semibold text-slate-200" htmlFor="description">
          Project Description
        </label>
        <textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Describe the project"
          className="min-h-[120px] rounded-xl border border-white/10 bg-white/90 px-4 py-3 text-slate-900 focus:border-cyan-400 focus:outline-none"
          required
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm font-semibold text-slate-200" htmlFor="image">
          Project Image URL
        </label>
        <input
          id="image"
          name="image"
          type="url"
          value={formData.image}
          onChange={handleChange}
          placeholder="https://example.com/image.jpg"
          className="rounded-xl border border-white/10 bg-white/90 px-4 py-3 text-slate-900 focus:border-cyan-400 focus:outline-none"
          required
        />
      </div>

      <button
        type="submit"
        className="w-full rounded-xl bg-cyan-400 px-6 py-3 text-sm font-semibold uppercase tracking-wide text-slate-900 transition hover:bg-cyan-300"
      >
        Save Project
      </button>
    </form>
  )
}
