import { useState } from 'react'
import axios from 'axios'

export default function Newsletter() {
  const [email, setEmail] = useState('')

  const handleSubmit = async (event) => {
    event.preventDefault()

    try {
      await axios.post('/api/newsletter', { email })
      alert('Subscribed successfully!')
      setEmail('')
    } catch (error) {
      console.error('Failed to subscribe', error)
      alert('Failed to subscribe.')
    }
  }

  return (
    <section className="bg-slate-950 px-6 py-16 text-white sm:px-8">
      <div className="mx-auto max-w-4xl rounded-3xl border border-white/10 bg-gradient-to-r from-slate-900/80 to-slate-800/80 p-8 shadow-2xl">
        <div className="mb-6 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.4em] text-cyan-300">Newsletter</p>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Subscribe Us</h2>
          <p className="mt-3 text-base text-slate-300">Insights on marketing, design, and launches delivered monthly.</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-3 text-slate-900 sm:flex-row"
        >
          <input
            type="email"
            name="email"
            placeholder="Enter Email Address"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="flex-1 rounded-xl border border-transparent bg-white/95 px-4 py-3 text-base text-slate-900 focus:border-cyan-300 focus:outline-none"
            required
          />
          <button
            type="submit"
            className="rounded-xl bg-cyan-400 px-6 py-3 text-sm font-semibold uppercase tracking-wide text-slate-900 transition hover:bg-cyan-300"
          >
            Subscribe
          </button>
        </form>
      </div>
    </section>
  )
}
