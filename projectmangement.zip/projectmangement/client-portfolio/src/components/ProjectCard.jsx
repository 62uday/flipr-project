export default function ProjectCard({ image, name, description }) {
  return (
    <article className="flex flex-col overflow-hidden rounded-2xl border border-white/5 bg-slate-900/60 shadow-lg shadow-black/20 backdrop-blur">
      <div className="relative h-52 w-full overflow-hidden">
        <img src={image} alt={name} className="h-full w-full object-cover transition duration-500 hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent opacity-0 transition hover:opacity-100" />
      </div>
      <div className="flex flex-1 flex-col gap-4 px-5 pb-6 pt-5">
        <div>
          <h3 className="text-xl font-semibold text-white">{name}</h3>
          <p className="mt-2 text-sm text-slate-300">{description}</p>
        </div>
        <button className="mt-auto w-fit rounded-full border border-cyan-400 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-cyan-100 transition hover:bg-cyan-400/10">
          Read More
        </button>
      </div>
    </article>
  )
}
