import { useEffect, useState } from 'react'
import axios from 'axios'
import accent from '../assets/images/Rectangle 55.png'
import ProjectCard from './ProjectCard'

export default function Projects() {
  const [projects, setProjects] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await axios.get('/api/projects')
        setProjects(response.data)
      } catch (err) {
        console.error('Failed to load projects', err)
        setError('Unable to load projects at the moment.')
      }
    }

    fetchProjects()
  }, [])

  return (
    <section id="projects" className="relative overflow-hidden bg-slate-950 px-6 py-20 text-white sm:px-8">
      <img src={accent} alt="" aria-hidden="true" className="pointer-events-none absolute -right-12 top-12 h-32 w-32 opacity-50" />

      <div className="relative mx-auto max-w-6xl">
        <div className="mb-10 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.4em] text-cyan-300">Our Work</p>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Our Projects</h2>
          <p className="mt-4 text-base text-slate-300">
            A curated glimpse at recent collaborations where strategy, design, and marketing intersect to elevate
            real estate experiences.
          </p>
        </div>

        {error ? (
          <p className="text-center text-sm text-red-300">{error}</p>
        ) : (
          <div className="grid gap-6 sm:gap-8 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <ProjectCard key={project._id || project.name} {...project} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
