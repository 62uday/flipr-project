import { useState } from 'react'
import axios from 'axios'

export default function ContactForm() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    mobileNumber: '',
    city: '',
  })

  const handleChange = (event) => {
    const { name, value } = event.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (event) => {
    event.preventDefault()

    try {
      await axios.post('/api/contacts', formData)
      alert('Form submitted successfully!')
      setFormData({ fullName: '', email: '', mobileNumber: '', city: '' })
    } catch (error) {
      console.error('Failed to submit contact form', error)
      alert('Failed to submit form.')
    }
  }

  return (
    <section className="bg-gradient-to-br from-slate-950 to-slate-900 px-6 py-20 text-white sm:px-8">
      <div className="mx-auto max-w-5xl rounded-3xl bg-[#0d1c3b] p-8 shadow-2xl sm:p-10 lg:p-14">
        <div className="mb-8 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.4em] text-cyan-300">Contact</p>
          <h2 className="mt-3 text-3xl font-bold text-white sm:text-4xl">Get a Free Consultation</h2>
        </div>

        <form onSubmit={handleSubmit} className="grid gap-6 md:grid-cols-2">
          <label className="flex flex-col gap-2 text-sm font-semibold text-slate-200">
            Full Name
            <input
              type="text"
              name="fullName"
              placeholder="Enter Full Name"
              value={formData.fullName}
              onChange={handleChange}
              className="rounded-xl border border-white/10 bg-white/95 px-4 py-3 text-slate-900 shadow-inner focus:border-cyan-300 focus:outline-none"
              required
            />
          </label>

          <label className="flex flex-col gap-2 text-sm font-semibold text-slate-200">
            Enter Email Address
            <input
              type="email"
              name="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={handleChange}
              className="rounded-xl border border-white/10 bg-white/95 px-4 py-3 text-slate-900 shadow-inner focus:border-cyan-300 focus:outline-none"
              required
            />
          </label>

          <label className="flex flex-col gap-2 text-sm font-semibold text-slate-200">
            Mobile Number
            <input
              type="tel"
              name="mobileNumber"
              placeholder="(+1) 555-123-4567"
              value={formData.mobileNumber}
              onChange={handleChange}
              className="rounded-xl border border-white/10 bg-white/95 px-4 py-3 text-slate-900 shadow-inner focus:border-cyan-300 focus:outline-none"
              required
            />
          </label>

          <label className="flex flex-col gap-2 text-sm font-semibold text-slate-200">
            Area, City
            <input
              type="text"
              name="city"
              placeholder="Downtown, Chicago"
              value={formData.city}
              onChange={handleChange}
              className="rounded-xl border border-white/10 bg-white/95 px-4 py-3 text-slate-900 shadow-inner focus:border-cyan-300 focus:outline-none"
              required
            />
          </label>

          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full rounded-2xl bg-gradient-to-r from-orange-400 to-orange-500 px-6 py-4 text-sm font-semibold uppercase tracking-wide text-slate-900 shadow-lg shadow-orange-500/30 transition hover:from-orange-300 hover:to-orange-400"
            >
              Get Quick Quote
            </button>
          </div>
        </form>
      </div>
    </section>
  )
}
