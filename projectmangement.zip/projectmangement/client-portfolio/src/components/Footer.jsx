import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from 'react-icons/fa'

const icons = [
  { id: 'facebook', Icon: FaFacebookF, href: '#facebook' },
  { id: 'twitter', Icon: FaTwitter, href: '#twitter' },
  { id: 'linkedin', Icon: FaLinkedinIn, href: '#linkedin' },
  { id: 'instagram', Icon: FaInstagram, href: '#instagram' },
]

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-slate-950 px-6 py-6 text-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-sm text-slate-300 md:flex-row">
        <p>© 2025 All Rights Reserved.</p>
        <div className="flex items-center gap-4 text-lg">
          {icons.map(({ id, Icon, href }) => (
            <a
              key={id}
              href={href}
              className="rounded-full border border-white/10 p-2 text-slate-100 transition hover:border-cyan-400 hover:text-cyan-300"
            >
              <Icon />
            </a>
          ))}
        </div>
      </div>
    </footer>
  )
}
