export default function ClientCard({ image, description, name, designation }) {
  return (
    <article className="flex h-full flex-col items-center gap-4 rounded-2xl bg-white/95 p-6 text-center shadow-xl shadow-black/10">
      <img src={image} alt={name} className="h-20 w-20 rounded-full object-cover" />
      <p className="text-sm text-slate-600">{description}</p>
      <div>
        <h3 className="text-base font-semibold text-slate-900">{name}</h3>
        <p className="text-xs font-medium uppercase tracking-wide text-cyan-600">{designation}</p>
      </div>
    </article>
  )
}
