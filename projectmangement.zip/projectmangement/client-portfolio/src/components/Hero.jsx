import ellipsePrimary from '../assets/images/Ellipse 1.png'
import ellipseAccent from '../assets/images/Ellipse 7.png'
import heroBg from '../assets/images/young-couple-examining-blueprints-with-real-estate-agent-while-buying-new-home 1.png'
import iconDollar from '../assets/images/circle-dollar-sign.png'
import iconHome from '../assets/images/home.png'
import iconBrush from '../assets/images/paintbrush-2.png'

const highlights = [
  { icon: iconHome, label: 'Smart Showings' },
  { icon: iconDollar, label: 'Value Engineering' },
  { icon: iconBrush, label: 'Creative Direction' },
]

export default function Hero() {
  return (
    <section
      id="home"
      className="relative isolate min-h-[calc(100vh-4rem)] w-full overflow-hidden bg-slate-900 text-white"
    >
      <img src={heroBg} alt="Clients reviewing blueprints" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950/85 via-slate-950/70 to-black/80" aria-hidden="true" />

      <img src={ellipsePrimary} alt="" className="pointer-events-none absolute -left-10 top-12 hidden h-60 w-60 opacity-70 sm:block" />
      <img src={ellipseAccent} alt="" className="pointer-events-none absolute bottom-10 right-10 h-48 w-48 opacity-50" />

      <div className="relative mx-auto flex min-h-[calc(100vh-4rem)] w-full max-w-6xl flex-col items-start justify-center gap-6 px-6 py-20 sm:px-8">
        <p className="text-base font-semibold uppercase tracking-[0.3em] text-cyan-300">Not Your Average Realtor</p>
        <h1 className="text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl">
          Consultation, Design & Marketing
        </h1>
        <p className="max-w-2xl text-base text-slate-100/80 sm:text-lg">
          Bespoke strategy that blends immersive visuals with high-converting campaigns, tailored for modern real
          estate brands ready to stand out.
        </p>

        <div className="grid w-full gap-4 sm:grid-cols-3">
          {highlights.map(({ icon, label }) => (
            <div key={label} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
              <img src={icon} alt="" className="h-8 w-8" />
              <p className="text-sm font-semibold text-white">{label}</p>
            </div>
          ))}
        </div>

        <button className="rounded-full bg-cyan-400 px-6 py-3 text-sm font-semibold uppercase tracking-wide text-slate-900 transition hover:bg-cyan-300">
          Why Choose Us?
        </button>
      </div>
    </section>
  )
}
