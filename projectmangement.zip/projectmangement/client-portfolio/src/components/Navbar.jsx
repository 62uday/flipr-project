import { useState } from 'react'
import logo from '../assets/images/logo.png'

const navLinks = ['Home', 'Services', 'Projects', 'Testimonials', 'Contact']

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => setIsMenuOpen((prev) => !prev)

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 md:px-8">
        <a href="#home" className="flex items-center gap-3 text-lg font-semibold tracking-tight text-white">
          <img src={logo} alt="Client Portfolio" className="h-10 w-10" />
          <span>
            Client<span className="text-cyan-400">Portfolio</span>
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="text-sm font-medium text-slate-200 transition hover:text-cyan-300"
            >
              {link}
            </a>
          ))}
          <button className="rounded-full border border-cyan-400 px-4 py-1.5 text-sm font-semibold text-cyan-100 transition hover:bg-cyan-400/10">
            Contact Us
          </button>
        </nav>

        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md border border-white/10 p-2 text-slate-200 transition hover:border-cyan-400 hover:text-cyan-300 md:hidden"
          aria-label="Toggle navigation menu"
          aria-expanded={isMenuOpen}
          onClick={toggleMenu}
        >
          <span className="sr-only">Menu</span>
          <svg
            className="h-5 w-5"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {isMenuOpen ? (
              <path d="M18 6 6 18M6 6l12 12" />
            ) : (
              <path d="M4 7h16M4 12h16M4 17h16" />
            )}
          </svg>
        </button>
      </div>

      {isMenuOpen && (
        <div className="border-t border-white/10 bg-slate-950/95 px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase()}`}
                className="text-base font-medium text-slate-100 transition hover:text-cyan-300"
                onClick={() => setIsMenuOpen(false)}
              >
                {link}
              </a>
            ))}
            <button className="rounded-full border border-cyan-400 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:bg-cyan-400/10">
              Contact Us
            </button>
          </nav>
        </div>
      )}
    </header>
  )
}
