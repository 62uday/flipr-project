import { useEffect, useState } from 'react'
import axios from 'axios'
import accent from '../assets/images/Rectangle 58.png'
import ClientCard from './ClientCard.jsx'

export default function Testimonials() {
  const [clients, setClients] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const response = await axios.get('/api/clients')
        setClients(response.data)
      } catch (err) {
        console.error('Failed to load clients', err)
        setError('Unable to load testimonials at the moment.')
      }
    }

    fetchClients()
  }, [])

  return (
    <section id="testimonials" className="relative overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 px-6 py-20 text-white sm:px-8">
      <img src={accent} alt="" aria-hidden="true" className="pointer-events-none absolute -left-12 top-16 h-28 w-28 opacity-60" />

      <div className="relative mx-auto max-w-6xl">
        <div className="mb-10 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.4em] text-cyan-300">Testimonials</p>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Happy Clients</h2>
          <p className="mt-4 text-base text-slate-300">
            Partnerships fueled by trust, transparency, and meticulous execution—hear from the leaders we support.
          </p>
        </div>

        {error ? (
          <p className="text-center text-sm text-red-300">{error}</p>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {clients.map((client) => (
              <ClientCard key={client._id || client.name} {...client} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
