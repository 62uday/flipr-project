const Newsletter = require('../models/Newsletter')

async function getSubscribers(req, res) {
  try {
    const subscribers = await Newsletter.find()
    res.status(200).json(subscribers)
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch subscribers', error: error.message })
  }
}

async function addSubscriber(req, res) {
  try {
    const { email } = req.body
    const subscriber = new Newsletter({ email })
    await subscriber.save()
    res.status(201).json(subscriber)
  } catch (error) {
    res.status(500).json({ message: 'Failed to add subscriber', error: error.message })
  }
}

module.exports = { getSubscribers, addSubscriber }
