const Project = require('../models/Project')

async function getProjects(req, res) {
  try {
    const projects = await Project.find()
    res.status(200).json(projects)
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch projects', error: error.message })
  }
}

async function addProject(req, res) {
  try {
    const { name, description } = req.body
    const imagePath = req.file ? req.file.path.replace(/\\/g, '/') : req.body.image

    if (!imagePath) {
      return res.status(400).json({ message: 'Project image is required' })
    }

    const project = new Project({ name, description, image: imagePath })
    await project.save()
    res.status(201).json(project)
  } catch (error) {
    res.status(500).json({ message: 'Failed to create project', error: error.message })
  }
}

module.exports = { getProjects, addProject }
