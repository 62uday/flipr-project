const Contact = require('../models/Contact')

async function getContacts(req, res) {
  try {
    const contacts = await Contact.find()
    res.status(200).json(contacts)
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch contacts', error: error.message })
  }
}

async function addContact(req, res) {
  try {
    const { fullName, email, mobileNumber, city } = req.body
    const contact = new Contact({ fullName, email, mobileNumber, city })
    await contact.save()
    res.status(201).json(contact)
  } catch (error) {
    res.status(500).json({ message: 'Failed to create contact', error: error.message })
  }
}

module.exports = { getContacts, addContact }
