const express = require('express')
const multer = require('multer')
const { storage } = require('../config/cloudinary')
const { getProjects, addProject } = require('../controllers/projectController')

const router = express.Router()

const upload = multer({ storage })

router.get('/', getProjects)
router.post('/', upload.single('image'), addProject)

module.exports = router
