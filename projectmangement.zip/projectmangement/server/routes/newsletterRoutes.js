const express = require('express')
const { getSubscribers, addSubscriber } = require('../controllers/newsletterController')

const router = express.Router()

router.get('/', getSubscribers)
router.post('/', addSubscriber)

module.exports = router
