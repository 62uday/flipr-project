const express = require('express')
const multer = require('multer')
const { storage } = require('../config/cloudinary')
const { getClients, addClient } = require('../controllers/clientController')

const router = express.Router()

const upload = multer({ storage })

router.get('/', getClients)
router.post('/', upload.single('image'), addClient)

module.exports = router
